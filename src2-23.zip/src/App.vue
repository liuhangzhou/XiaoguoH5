<template>
  <div>
    <router-view/>
  </div>
</template>

<style>
@import "assets/css/public.css";
@import "assets/css/index.css";
</style>
